Close All Add-On
================

A new button in the task manager to close all (closable) windows.

Scythe icon from http://www.iconsplace.com/black-icons/scythe-icon